// Implements an array data structure with operations for inserting and deleting
public class PatientTriage
{

    // Array of Patients will have a capacity and totalPatients is the amount of
    // capacity used, i.e. the number of elements in the array referencing
    // actual Patient objects.
    private Patient[] patients;
    private int capacity;
    private int totalPatients;

    // The array is instantiated with a provided capacity, initially no patients
    PatientTriage(int capacity)
    {
        patients = new Patient[capacity];
        this.capacity = capacity;
        totalPatients = 0;
    }

    // Returns true if the triage is empty, false otherwise
    boolean isEmpty()
    {
        if (totalPatients == 0) return true;
        else return false;
    }

    // A "getter" method that returns the total number of patients in the triage
    int getTotalPatients()
    {
        return totalPatients;
    }

    // Output the patients and the total number of patients
    void printPatients()
    {
        System.out.println("\n********** Patient Triage Status **********");
        for (int i = 0; i < totalPatients; i++)
            System.out.println(i + ": " + patients[i].name);
        System.out.println("\n" + totalPatients + " patients total.\n");
    }

    boolean isMember(String name) {
        for (int i = 0; i < totalPatients; i++) {
            if (name.equals(patients[i].name)) {
                return true;
            }
        }
        return false;
    }

    void leftRotate() {
        if (totalPatients > 1) {
            Patient temp = patients[0];
            for (int i = 1; i < totalPatients; i++) {
                patients[i -1] = patients[i];
            }
            patients[totalPatients - 1] = temp;
        }
    }

    // Inserts a new patient at the end of the triage
    boolean insertAtEnd(Patient newPatient)
    {
        if (totalPatients + 1 > capacity) return false;

        patients[totalPatients] = newPatient;
        totalPatients++;

        return true;
    }

    // Inserts a new patient at the start of the triage... notice how we can
    // implement this function either using insertAtIndex or "manually"
    boolean insertAtStart(Patient newPatient)
    {
        return insertAtIndex(newPatient, 0);

        /*
        if (totalPatients + 1 > capacity) return false;

        for (int i = totalPatients; i > 0; i--)
            patients[i] = patients[i - 1];

        patients[0] = newPatient;
        totalPatients++;

        return true;

         */
    }

    // Inserts a patient at a provided index
    boolean insertAtIndex(Patient newPatient, int index)
    {
        if (totalPatients + 1 > capacity) return false;

        for (int i = totalPatients; i > index; i--)
            patients[i] = patients[i - 1];

        patients[index] = newPatient;
        totalPatients++;

        return true;
    }

    // Deletes a patient at an index
    boolean deleteAtIndex(int index)
    {
        if (index >= totalPatients) return false;

        for (int i = index; i < totalPatients; i++)
            patients[i] = patients[i + 1];

        totalPatients--;

        return true;
    }

}
