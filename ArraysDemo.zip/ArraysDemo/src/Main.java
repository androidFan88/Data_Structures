public class Main {
    public static void main(String[] args) {

        // Test out the PatientTriage array data structure

        PatientTriage triage = new PatientTriage(50);

        if (triage.isEmpty()) System.out.println("Patient triage is empty!");
        else System.out.println("Patient triage is not empty.");

        System.out.println("Total Patients: " + triage.getTotalPatients());

        triage.printPatients();

        triage.insertAtEnd(new Patient("Ali"));
        triage.printPatients();

        triage.insertAtEnd(new Patient("Sam"));
        triage.printPatients();

        triage.insertAtEnd(new Patient("Kayla"));
        triage.printPatients();

        triage.insertAtStart(new Patient("Mary"));
        triage.printPatients();

        triage.insertAtIndex(new Patient("Moe"), 2);
        triage.printPatients();

        triage.deleteAtIndex(1);
        triage.printPatients();

        if (triage.isEmpty()) System.out.println("Patient triage is empty!\n");
        else System.out.println("Patient triage is not empty.");

        System.out.println(triage.isMember("Moe"));

        triage.leftRotate();
        triage.printPatients();
        triage.leftRotate();
        triage.printPatients();

        System.out.println("Total Patients: " + triage.getTotalPatients());

    }
}