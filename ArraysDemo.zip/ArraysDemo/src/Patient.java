// A simple Patient object type to store in our array data structure

public class Patient
{
    public String name;

    Patient(String name)
    {
        this.name = name;
    }

}
