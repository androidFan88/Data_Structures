// Represents a node in our LinkedList.  Each Node will store a value and a
// reference to the next Node.
public class Node
{
    public int value;

    public Node next;

    Node(int set_value)
    {
        value = set_value;
        next = null;
    }
}
