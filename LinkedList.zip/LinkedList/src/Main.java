// Test out the LinkedList data structure
public class Main {
    public static void main(String[] args)
    {
        // Create a new linked list
        LinkedList list = new LinkedList();

        // Test out the various operations we have implemented
        if (list.isEmpty())
            System.out.println("List is empty.");

        if (!list.deleteHeadNode())
            System.out.println("Cannot delete head node, list is empty.");

        if (!list.deleteTailNode())
            System.out.println("Cannot delete tail node, list is empty.");

        list.insertAtHead(5);
        list.printList();

        if (!list.isEmpty())
            System.out.println("List is not empty.");

        list.insertAtHead(8);
        list.printList();

        list.insertAtHead(4);
        list.printList();

        list.insertAtTail(9);
        list.printList();

        if (list.deleteHeadNode())
            System.out.println("Head node deleted!");
        list.printList();

        if (list.deleteTailNode())
            System.out.println("Tail node deleted!");
        list.printList();

        if (list.deleteTailNode())
            System.out.println("Tail node deleted!");
        list.printList();

        if (list.deleteTailNode())
            System.out.println("Tail node deleted!");
        list.printList();

        if (!list.deleteTailNode())
            System.out.println("Cannot delete tail node, list is empty.");

        list.insertAtTail(12);
        list.insertAtTail(17);
        list.insertAtTail(14);
        list.insertAtTail(19);
        list.insertAtTail(11);
        list.printList();

        list.insertAtPosition(21, 0);
        list.printList();

        list.insertAtPosition(22, 1);
        list.printList();

        list.insertAtPosition(23, 4);
        list.printList();

        list.insertAtPosition(24, 7);
        list.printList();

        list.insertAtPosition(25, 9);
        list.insertAtPosition(25, 3);
        list.printList();

        list.deleteAllMatches(25);

        list.printList();

    }
}