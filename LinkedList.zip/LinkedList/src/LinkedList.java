// LinkedList data structure
public class LinkedList
{
    // A reference to the head node in the list is maintained as a
    // member variable
    private Node head;

    // When the list is initially created it will be empty and head will
    // reference null
    LinkedList()
    {
        head = null;
    }

    boolean isMember(int item) {
        Node temp = head;
        while (temp != null) {
            if (item == temp.value) {
                return true;
            }
            temp = temp.next;
        }
        return false;
    }

    boolean deleteAtPosition(int index) {
        if (index == 0) return deleteHeadNode();
        else {
            Node prev = head;
            Node temp = head.next;
            int length = 1;

            while (temp != null) {
                if (index == length) {
                    prev.next = temp.next;
                    return true;
                }
                length++;
                prev = temp;
                temp = temp.next;
            }
            return false;
        }
    }

    void deleteAllMatches(int item) {
        if (item == head.value) deleteHeadNode();
        else {
            Node prev = head;
            Node temp = head.next;
            while (temp != null) {
                if (temp.value == item) {
                    prev.next = temp.next;
                }
                prev = temp;
                temp = temp.next;
            }
        }
    }


    int calculateTotal () {
        int total = 0;
        Node temp = head;
        while (temp != null) {
            total += temp.value;
            temp = temp.next;
        }
        return total;
    }

    // If head referencing null we know the list is empty
    boolean isEmpty()
    {
        if (head == null) return true;
        else return false;
    }

    // We output the values in the list by traversing the list using a Node
    // reference variable currentNode
    void printList()
    {
        // Initially currentNode will refer to the head node
        Node currentNode = head;

        System.out.print("List: ");

        // When currentNode reaches null we know we have reached the end of
        // the list and can stop
        while (currentNode != null)
        {
            // Output the value at the current node
            System.out.print(currentNode.value + " ");

            // Set currentNode to refer to the *next* node in the list as
            // given by currentNode.next
            currentNode = currentNode.next;
        }

        System.out.print("\n");
    }

    // Inserts a new Node with the given value at the head of the list
    void insertAtHead(int value)
    {
        // Instantiate the new Node object
        Node newNode = new Node(value);

        // Set the new node to reference the head as the next node
        newNode.next = head;

        // Set this new node as the head node
        head = newNode;
    }

    // Inserts a new node with the given value at the tail of the list
    void insertAtTail(int value)
    {
        // Instantiate the new Node object
        Node newNode = new Node(value);

        // If the list is not empty, we need to traverse the list to find the
        // tail in order to put the new node there
        if (head != null)
        {
            // Set currentNode to the head
            Node currentNode = head;

            // Keep setting currentNode to the next node in the list until we
            // reach the tail of the list, where the tail of the list is the
            // node whose next member variable references null (i.e. nothing)
            while (currentNode.next != null)
                currentNode = currentNode.next;

            // Set the last node in the list to reference the new node
            currentNode.next = newNode;
        }
        // otherwise if the list IS empty we just set head to be this new Node
        else head = newNode;
    }

    // Deletes the head node in the list (if it exists).  If no head node
    // exists false is returned, otherwise true is returned.  This is just to
    // let the code that called this function know whether or not a node was
    // deleted at all.
    boolean deleteHeadNode()
    {
        // if the list is empty we can't delete a node, so return false
        if (head == null) return false;
        else
        {
            // Otherwise if the list is not empty we delete the head by having
            // head reference head.next.  We return true to acknowledge a
            // node has been deleted.
            head = head.next;
            return true;
        }
    }

    // Deletes the tail node in the list (if it exists).  If no tail node
    // exists false is returned, otherwise true is returned.  This is just to
    // let the code that called this function know whether or not a node was
    // deleted at all.
    boolean deleteTailNode()
    {
        // if the list is not empty, we need to find the tail node by
        // traversing the list
        if (head != null)
        {
            // To remove the tail node, we want to set the node *previous* to
            // the tail node to reference null... chopping off the tail node
            // from the list.  i.e. the second last node in the list needs to
            // reference nothing.  So we'll traverse the list, but this time
            // keep track of the previousNode as well as the currentNode.
            Node currentNode = head;
            Node previousNode = null;

            // If currentNode.next does equal null we'll know we've reached
            // the tail of the list... so long as this isn't true we'll keep
            // traversing the list.
            while (currentNode.next != null)
            {
                // Set previousNode to the currentNode to keep track of the
                // previous node from the current node
                previousNode = currentNode;

                // Set currentNode to the next node
                currentNode = currentNode.next;
            }

            // If the previousNode is null, which is what it was initially set
            // to, this means the list only contained a single node (the head).
            // In this case we can delete the tail by just setting head to null.
            //
            // Otherwise, previousNode will reference the second last node in
            // the list, and we can delete the tail node by setting this second
            // last node to reference null (i.e. nothing) instead of the last
            // node in the list.
            if (previousNode == null) head = null;
            else previousNode.next = null;

            // We return true to acknowledge a node has been deleted
            return true;
        }
        // if the list is empty there is no tail node to delete, and so we
        // return false to acknowledge no node was actually deleted
        else return false;
    }

    // Inserts a new node with the supplied value at the supplied position,
    // where the first node in the list is considered to be at position 0,
    // the second node in the list is considered to be at position 1, and
    // so on.  If the position is one more than the position of the tail
    // node, the node will be inserted after the curren tail node as the
    // new tail node.  If the position is beyond one more than the
    // position of the tail node, the function will return false and not
    // insert a new node.  If a new node is inserted at the position
    // successfully the function will return true.
    boolean insertAtPosition(int value, int position)
    {
        // We'll need to traverse the list to find the right position to
        // insert the new node.  We keep track of the current position with
        // the currentPosition variable (initially 0 because we are at the
        // head of the list).
        int currentPosition = 0;

        // We'll use currentNode to keep track of the current node we are
        // referencing, and previousNode to keep track of the node prior to
        // the current node.  In order to insert the node at a position,
        // unless that position is the head, it will be necessary to have the
        // node prior to that position refer to this new node (and the new
        // node will refer to the node previously at this position, if any).
        Node currentNode = head;
        Node previousNode = null;

        // Keep traversing through the linked list until we reach the desired
        // position in the list
        while (currentPosition != position)
        {
            // if the currentNode is null, we have reached the end of the list
            // but the desired position to insert the node is beyond this
            // position... so we cannot insert a node at the desired position
            // and return false instead
            if (currentNode == null) return false;

            // Set previous node to the current node, advance the current
            // node by having it reference the next node
            previousNode = currentNode;
            currentNode = currentNode.next;

            // Increment currentPosition as we have advanced by another node
            // in our traversal of the list
            currentPosition++;
        }

        // Once the loop above is done we'll have reached the position in
        // the list where we wish to insert the node... so we first instantiate
        // the new node to insert.
        Node newNode = new Node(value);

        // If the previousNode is null, this means we want to insert the new
        // Node at the head
        if (previousNode == null)
        {
            // In this case we just set the new node's next member variable to
            // reference the old head, and we set head to now reference the
            // new node as it is the new head.
            newNode.next = head;
            head = newNode;
        }
        // Otherwise we are inserting the node either in the middle of the list
        // somewhere or possibly at the tail
        else
        {
            // Set node prior to the current node to reference this new node,
            // this will insert the node at the desired position
            previousNode.next = newNode;

            // Have the new node's next member reference the current node,
            // joining the remainder of the list after this new node... it's
            // possible that current node could be null if we have reached
            // the very tail of the list, but that's OK too!
            newNode.next = currentNode;
        }

        // Return true to acknowledge that a node has been inserted
        return true;
    }
}