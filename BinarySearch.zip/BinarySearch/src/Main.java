public class Main {
    public static void main(String[] args) {

        int[] numbers = {1,4,5,6,9,12,16,19,21,25,26,30,31,33,35,38,40,42,46,51,53,57,60,61,68,72};
        Search binary = new Search(numbers);

        System.out.println("The requested element took : " + binary.binarySearch(61) + " Recursions to find");

    }
}