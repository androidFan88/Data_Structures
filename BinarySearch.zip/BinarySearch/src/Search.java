public class Search {

    private int[] data;
    private int numElements;
    Search (int[] a) {
        data = a;
        numElements = data.length;
    }

    void printData () {
        for (int i = 0; i < data.length; i++) {
            System.out.print(data[i] + " , ");
        }
    }


    int binarySearch (int elem) {
        boolean notFound = false;
        int count = 0;
        int upper = numElements;
        int lower = 0;
        int middle = upper / 2;
        while (elem != data[middle]) {
            if ((upper - lower) == 1) {
                notFound = true;
                break;
            }
            if (elem > data[middle]) {
                lower = middle;
                middle += (upper - lower) / 2;
            }
            else {
                upper = middle;
                middle -= (upper - lower) / 2;
            }
            count++;
        }
        if (!notFound) {
            System.out.println("The element you selected is " + data[middle]);
        }
        else {
            System.out.println("The nearest element to " + elem + " is " + data[middle]);
        }
        return count;
    }

}
